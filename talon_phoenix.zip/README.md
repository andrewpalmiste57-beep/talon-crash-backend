# TALON Crash Game — Phoenix Backend

## Deploy

### Fly.io (Recommended for 400K+ concurrent)
```bash
fly launch --dockerfile Dockerfile
fly deploy
```

### Render
Push to GitHub, connect repo in Render dashboard. Uses `render.yaml` blueprint.

### Local
```bash
mix deps.get
mix ecto.setup
mix phx.server
```

## Env Vars
- `DATABASE_URL` — Postgres connection string
- `SECRET_KEY_BASE` — 64+ char secret
- `REDIS_URL` — Optional, for multi-node PubSub
- `PHX_HOST` — Canonical host
- `TALON_CLIENT_SEED` — Fixed client seed for provably fair

## WebSocket
`wss://HOST/socket/websocket?user_id=UUID&vsn=2.0.0`

## Protocol
- Join `game:global`
- Server pushes: `round.start`, `round.flying`, `round.sync`, `round.crash`
- Client sends: `bet.place`, `bet.cancel`, `bet.cashout`, `ping`
- Heartbeat: server expects `pong` within 9s

## Provably Fair
Crash = max(1.00, (2^52 / (int + 1)) * 0.99)
where int = first 52 bits of HMAC-SHA256(server_seed, client_seed:nonce)
Verify via `/api/verify?server_seed=...&client_seed=...&nonce=...&crash_point=...`
