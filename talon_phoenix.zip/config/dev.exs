import Config

config :talon, Talon.Repo,
  username: System.get_env("DB_USER", "postgres"),
  password: System.get_env("DB_PASS", "postgres"),
  hostname: System.get_env("DB_HOST", "localhost"),
  database: System.get_env("DB_NAME", "talon_dev"),
  stacktrace: true,
  show_sensitive_data_on_connection_error: true,
  pool_size: 10,
  queue_target: 50,
  queue_interval: 1000

config :talon, TalonWeb.Endpoint,
  http: [ip: {0, 0, 0, 0}, port: String.to_integer(System.get_env("PORT", "4000"))],
  secret_key_base: System.get_env("SECRET_KEY_BASE", "devsecretdevsecretdevsecretdevsecretdevsecretdevsecretdevsecretdevsecret"),
  debug_errors: true

config :logger, :console, format: "[$level] $message\n"
config :phoenix, :stacktrace_depth, 20
config :phoenix, :plug_init_mode, :runtime
