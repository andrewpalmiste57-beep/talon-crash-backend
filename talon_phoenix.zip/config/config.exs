import Config

config :talon,
  ecto_repos: [Talon.Repo],
  generators: [timestamp_type: :utc_datetime_usec],
  betting_duration_ms: 10_000,
  crash_display_ms: 3_000,
  tick_interval_ms: 50,
  heartbeat_interval_ms: 3_000,
  heartbeat_timeout_ms: 9_000,
  house_edge: 0.01,
  min_auto_cashout: 1.01,
  min_stake: 1,
  max_stake: 10_000,
  max_bets_per_round: 2,
  rate_limit_bets: {10, 60_000},
  rate_limit_connect: {5, 10_000}

config :talon, TalonWeb.Endpoint,
  url: [host: "localhost"],
  adapter: Phoenix.Endpoint.Cowboy2Adapter,
  render_errors: [
    formats: [json: TalonWeb.ErrorJSON],
    layout: false
  ],
  pubsub_server: Talon.PubSub,
  live_view: [signing_salt: System.get_env("SECRET_KEY_BASE", "devsaltchangeme")],
  check_origin: false,
  http: [compress: true],
  code_reloader: true

config :logger, :console,
  format: "$time $metadata[$level] $message\n",
  metadata: [:request_id]

config :phoenix, :json_library, Jason

import_config "#{config_env()}.exs"
