import Config

if config_env() == :prod do
  database_url = System.get_env("DATABASE_URL") || raise "DATABASE_URL missing"
  secret_key_base = System.get_env("SECRET_KEY_BASE") || raise "SECRET_KEY_BASE missing"
  host = System.get_env("PHX_HOST") || "localhost"
  port = String.to_integer(System.get_env("PORT", "4000"))
  redis_url = System.get_env("REDIS_URL")

  config :talon, Talon.Repo,
    url: database_url,
    pool_size: String.to_integer(System.get_env("POOL_SIZE", "20")),
    queue_target: 50,
    queue_interval: 1000,
    prepare: :named,
    parameters: [application_name: "talon_game"]

  config :talon, TalonWeb.Endpoint,
    url: [host: host, port: 443, scheme: "https"],
    http: [ip: {0,0,0,0}, port: port, compress: true, protocol_options: [idle_timeout: 120_000]],
    secret_key_base: secret_key_base,
    check_origin: ["https://" <> host, "https://*." <> host],
    server: true

  if redis_url do
    config :talon, :pubsub_adapter, Phoenix.PubSub.Redis
    config :talon, :pubsub_redis_url, redis_url
  end
end
