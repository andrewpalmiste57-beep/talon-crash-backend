defmodule Talon do
  @moduledoc "Talon Crash Game — Warp Vortex Protocol"
end
