defmodule Talon.Application do
  @moduledoc false
  use Application

  @impl true
  def start(_type, _args) do
    pubsub_adapter = Application.get_env(:talon, :pubsub_adapter, Phoenix.PubSub.PG2)
    pubsub_opts = [name: Talon.PubSub, adapter: pubsub_adapter]
    pubsub_opts = if pubsub_adapter == Phoenix.PubSub.Redis do
      Keyword.put(pubsub_opts, :redis_url, Application.get_env(:talon, :pubsub_redis_url, "redis://localhost:6379"))
    else
      pubsub_opts
    end

    children = [
      Talon.Repo,
      {Phoenix.PubSub, pubsub_opts},
      {Talon.Game.GameServer, []},
      {Talon.Bets.BetProcessor, []},
      {Cachex, name: :talon_cache},
      TalonWeb.Endpoint
    ]

    opts = [strategy: :one_for_one, name: Talon.Supervisor]
    Supervisor.start_link(children, opts)
  end

  @impl true
  def config_change(changed, _new, removed) do
    TalonWeb.Endpoint.config_change(changed, removed)
    :ok
  end
end
