defmodule Talon.Game.GameServer do
  @moduledoc """
  Singleton game state machine.
  Phases: :betting -> :flying -> :crashed -> repeat
  All timing derived from monotonic System.monotonic_time / System.system_time.
  """
  use GenServer
  require Logger

  alias Talon.Game.CrashCalculator
  alias Talon.Bets.BetProcessor

  @betting_ms 10_000
  @crash_display_ms 3_000
  @growth_rate 0.06
  @sync_interval_ms 250

  defstruct [
    :round_id, :phase, :server_seed, :client_seed, :server_seed_hash,
    :crash_point, :start_time_mono, :start_time_sys, :bets,
    :betting_timer, :crash_timer, :sync_timer, :jackpot, :player_count
  ]

  def start_link(_), do: GenServer.start_link(__MODULE__, [], name: __MODULE__)
  def state, do: GenServer.call(__MODULE__, :get_state)
  def place_bet(user_id, side, stake, auto_cashout, key) do
    GenServer.call(__MODULE__, {:place_bet, user_id, side, stake, auto_cashout, key})
  end
  def cancel_bet(user_id, side, key) do
    GenServer.call(__MODULE__, {:cancel_bet, user_id, side, key})
  end
  def cash_out(user_id, side) do
    GenServer.call(__MODULE__, {:cash_out, user_id, side})
  end
  def sync_time, do: GenServer.call(__MODULE__, :sync_time)

  @impl true
  def init(_) do
    client_seed = System.get_env("TALON_CLIENT_SEED") || CrashCalculator.generate_seed()
    :ok = Phoenix.PubSub.subscribe(Talon.PubSub, "game:global")
    send(self(), :start_round)
    {:ok, %__MODULE__{
      round_id: 0, phase: :idle, client_seed: client_seed,
      bets: %{}, jackpot: 1_250_340.50, player_count: 0
    }}
  end

  @impl true
  def handle_call(:get_state, _from, state) do
    {:reply, serialize_state(state), state}
  end

  def handle_call(:sync_time, _from, state) do
    {:reply, %{server_time: System.system_time(:millisecond), round: serialize_state(state)}, state}
  end

  def handle_call({:place_bet, user_id, side, stake, auto_cashout, key}, _from, %{phase: :betting} = state) do
    result = BetProcessor.debit_and_place(state.round_id, user_id, side, stake, auto_cashout, key)
    case result do
      {:ok, bet} ->
        bets = Map.put(state.bets, {user_id, side}, bet)
        broadcast("bet_placed", %{user_id: user_id, side: side, stake: stake})
        {:reply, {:ok, bet}, %{state | bets: bets}}
      {:error, reason} ->
        {:reply, {:error, reason}, state}
    end
  end
  def handle_call({:place_bet, _, _, _, _, _}, _from, state) do
    {:reply, {:error, "betting_closed"}, state}
  end

  def handle_call({:cancel_bet, user_id, side, key}, _from, %{phase: :betting} = state) do
    case Map.pop(state.bets, {user_id, side}) do
      {nil, _} -> {:reply, {:error, "no_bet"}, state}
      {bet, bets} ->
        BetProcessor.refund(bet, key)
        broadcast("bet_cancelled", %{user_id: user_id, side: side, refund: bet.stake})
        {:reply, :ok, %{state | bets: bets}}
    end
  end
  def handle_call({:cancel_bet, _, _, _}, _from, state) do
    {:reply, {:error, "cannot_cancel"}, state}
  end

  def handle_call({:cash_out, user_id, side}, _from, %{phase: :flying} = state) do
    case Map.get(state.bets, {user_id, side}) do
      nil -> {:reply, {:error, "no_bet"}, state}
      %{cashed_out_at: nil} = bet ->
        elapsed = mono_elapsed(state.start_time_mono)
        multiplier = :math.exp(@growth_rate * elapsed)
        payout = Float.floor(bet.stake * multiplier * 100) / 100
        BetProcessor.credit_win(user_id, payout)
        updated = %{bet | cashed_out_at: multiplier, payout: payout}
        bets = Map.put(state.bets, {user_id, side}, updated)
        broadcast("cash_out", %{user_id: user_id, side: side, multiplier: multiplier, payout: payout})
        {:reply, {:ok, %{multiplier: multiplier, payout: payout}}, %{state | bets: bets}}
      _ ->
        {:reply, {:error, "already_cashed"}, state}
    end
  end
  def handle_call({:cash_out, _, _}, _from, state) do
    {:reply, {:error, "not_flying"}, state}
  end

  @impl true
  def handle_info(:start_round, state) do
    round_id = state.round_id + 1
    server_seed = CrashCalculator.generate_seed()
    server_seed_hash = CrashCalculator.hash_server_seed(server_seed)
    nonce = round_id
    crash_point = CrashCalculator.calculate(server_seed, state.client_seed, nonce)
    start_mono = System.monotonic_time(:millisecond)
    start_sys = System.system_time(:millisecond)
    betting_timer = Process.send_after(self(), :end_betting, @betting_ms)

    broadcast("round.start", %{
      round_id: round_id, server_time: start_sys,
      server_seed_hash: server_seed_hash, betting_duration: @betting_ms, phase: "betting"
    })

    {:noreply, %{state |
      round_id: round_id, phase: :betting, server_seed: server_seed,
      server_seed_hash: server_seed_hash, crash_point: crash_point, nonce: nonce,
      start_time_mono: start_mono, start_time_sys: start_sys, bets: %{},
      betting_timer: betting_timer, player_count: connected_players()
    }}
  end

  def handle_info(:end_betting, state) do
    Process.cancel_timer(state.betting_timer)
    start_mono = System.monotonic_time(:millisecond)
    start_sys = System.system_time(:millisecond)
    flight_duration = trunc(:math.log(state.crash_point) / @growth_rate * 1000)
    crash_timer = Process.send_after(self(), :do_crash, flight_duration)
    sync_timer = Process.send_after(self(), :sync_tick, @sync_interval_ms)

    broadcast("round.flying", %{
      round_id: state.round_id, server_time: start_sys, phase: "flying"
    })

    {:noreply, %{state |
      phase: :flying, start_time_mono: start_mono, start_time_sys: start_sys,
      crash_timer: crash_timer, sync_timer: sync_timer
    }}
  end

  def handle_info(:sync_tick, %{phase: :flying} = state) do
    elapsed = mono_elapsed(state.start_time_mono)
    multiplier = :math.exp(@growth_rate * elapsed)
    broadcast("round.sync", %{
      round_id: state.round_id, server_time: System.system_time(:millisecond),
      multiplier: Float.floor(multiplier * 100) / 100, elapsed_ms: elapsed * 1000
    })
    sync_timer = Process.send_after(self(), :sync_tick, @sync_interval_ms)
    {:noreply, %{state | sync_timer: sync_timer}}
  end
  def handle_info(:sync_tick, state), do: {:noreply, state}

  def handle_info(:do_crash, state) do
    Process.cancel_timer(state.crash_timer)
    Process.cancel_timer(state.sync_timer)

    bets = Enum.map(state.bets, fn {key, bet} ->
      if bet.cashed_out_at == nil and bet.auto_cashout >= 1.01 and state.crash_point >= bet.auto_cashout do
        payout = Float.floor(bet.stake * bet.auto_cashout * 100) / 100
        BetProcessor.credit_win(bet.user_id, payout)
        broadcast("cash_out", %{user_id: bet.user_id, side: bet.side, multiplier: bet.auto_cashout, payout: payout, auto: true})
        {key, %{bet | cashed_out_at: bet.auto_cashout, payout: payout}}
      else
        {key, bet}
      end
    end) |> Map.new()

    Enum.each(bets, fn {_, bet} ->
      if bet.cashed_out_at == nil, do: BetProcessor.record_loss(bet)
    end)

    Task.start(fn -> persist_round(state, bets) end)

    broadcast("round.crash", %{
      round_id: state.round_id, crash_point: state.crash_point,
      server_seed: state.server_seed, server_time: System.system_time(:millisecond)
    })

    crash_timer = Process.send_after(self(), :start_round, @crash_display_ms)
    {:noreply, %{state |
      phase: :crashed, bets: bets, crash_timer: crash_timer,
      jackpot: state.jackpot + :rand.uniform(50), player_count: connected_players()
    }}
  end

  def handle_info(%Phoenix.Socket.Broadcast{event: "presence_diff"}, state) do
    {:noreply, %{state | player_count: connected_players()}}
  end
  def handle_info(_, state), do: {:noreply, state}

  defp mono_elapsed(start_mono) do
    (System.monotonic_time(:millisecond) - start_mono) / 1000.0
  end

  defp broadcast(event, payload) do
    Phoenix.PubSub.broadcast(Talon.PubSub, "game:global", %Phoenix.Socket.Broadcast{
      topic: "game:global", event: event, payload: payload
    })
  end

  defp connected_players do
    :rand.uniform(300) + 120
  end

  defp serialize_state(state) do
    %{
      round_id: state.round_id, phase: state.phase,
      server_seed_hash: state.server_seed_hash,
      crash_point: if(state.phase == :crashed, do: state.crash_point, else: nil),
      server_time: System.system_time(:millisecond),
      start_time: state.start_time_sys,
      jackpot: Float.floor(state.jackpot * 100) / 100,
      players: state.player_count
    }
  end

  defp persist_round(state, bets) do
    total_bets = map_size(bets)
    total_wagered = Enum.reduce(bets, 0, fn {_, b}, acc -> acc + b.stake end)
    total_payout = Enum.reduce(bets, 0, fn {_, b}, acc -> acc + (b.payout || 0) end)
    Talon.Repo.insert!(%Talon.Game.Round{
      round_number: state.round_id, server_seed_hash: state.server_seed_hash,
      server_seed: state.server_seed, client_seed: state.client_seed, nonce: state.nonce,
      crash_point: state.crash_point,
      started_at: DateTime.from_unix!(div(state.start_time_sys, 1000), :second),
      crashed_at: DateTime.utc_now(), total_bets: total_bets,
      total_wagered: Decimal.from_float(total_wagered * 1.0),
      total_payout: Decimal.from_float(total_payout * 1.0)
    })
  end
end
