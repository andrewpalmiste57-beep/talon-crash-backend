defmodule Talon.Game.CrashCalculator do
  @moduledoc """
  Provably fair crash-point generation.
  Uses HMAC-SHA256(server_seed, client_seed:nonce).
  Revealed after round ends for verification.
  """

  @house_edge 0.01
  @min_crash 1.00
  @cutoff 1.01

  def generate_seed do
    :crypto.strong_rand_bytes(32)
    |> Base.encode16(case: :lower)
  end

  def hash_server_seed(seed) do
    :crypto.hash(:sha256, seed)
    |> Base.encode16(case: :lower)
  end

  def calculate(server_seed, client_seed, nonce \\ 0) do
    hash = :crypto.mac(:hmac, :sha256, server_seed, "#{client_seed}:#{nonce}")
    |> Base.encode16(case: :lower)

    int = hash
    |> String.slice(0, 13)
    |> String.to_integer(16)

    result = :math.pow(2, 52) / (int + 1)
    crash = result * (1 - @house_edge)

    if crash < @cutoff, do: @min_crash, else: Float.floor(crash * 100) / 100
  end

  def verify(server_seed, client_seed, nonce, claimed_crash) do
    calculated = calculate(server_seed, client_seed, nonce)
    abs(calculated - claimed_crash) < 0.001
  end
end
