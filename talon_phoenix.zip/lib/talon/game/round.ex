defmodule Talon.Game.Round do
  @moduledoc "Round schema for persistence & audit."
  use Ecto.Schema
  import Ecto.Changeset

  schema "rounds" do
    field :round_number, :integer
    field :server_seed_hash, :string
    field :server_seed, :string
    field :client_seed, :string
    field :nonce, :integer
    field :crash_point, :float
    field :started_at, :utc_datetime_usec
    field :crashed_at, :utc_datetime_usec
    field :total_bets, :integer, default: 0
    field :total_wagered, :decimal, default: 0
    field :total_payout, :decimal, default: 0
    has_many :bets, Talon.Bets.Bet
    timestamps(type: :utc_datetime_usec)
  end

  def changeset(round, attrs) do
    round
    |> cast(attrs, [:round_number, :server_seed_hash, :server_seed, :client_seed, :nonce,
                    :crash_point, :started_at, :crashed_at, :total_bets, :total_wagered, :total_payout])
    |> validate_required([:round_number, :server_seed_hash, :crash_point])
    |> unique_constraint(:round_number)
  end
end
