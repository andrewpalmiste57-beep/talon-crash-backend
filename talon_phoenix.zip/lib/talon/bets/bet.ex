defmodule Talon.Bets.Bet do
  @moduledoc "Bet schema."
  use Ecto.Schema
  import Ecto.Changeset

  schema "bets" do
    field :round_id, :integer
    field :user_id, :string
    field :side, :string
    field :stake, :float
    field :auto_cashout, :float
    field :cashed_out_at, :float
    field :payout, :float
    field :idempotency_key, :string
    field :status, :string, default: "pending"
    timestamps(type: :utc_datetime_usec)
  end

  def changeset(bet, attrs) do
    bet
    |> cast(attrs, [:round_id, :user_id, :side, :stake, :auto_cashout,
                    :cashed_out_at, :payout, :idempotency_key, :status])
    |> validate_required([:round_id, :user_id, :side, :stake, :idempotency_key])
    |> validate_number(:stake, greater_than_or_equal_to: 1)
    |> unique_constraint([:idempotency_key])
  end
end
