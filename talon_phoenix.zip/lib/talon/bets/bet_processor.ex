defmodule Talon.Bets.BetProcessor do
  @moduledoc """
  Idempotent bet processing with Redis-backed deduplication.
  All wallet mutations happen here. No client trust.
  """
  use GenServer
  alias Talon.Repo
  alias Talon.Bets.Bet

  @idempotency_ttl 300

  def start_link(_), do: GenServer.start_link(__MODULE__, [], name: __MODULE__)

  def debit_and_place(round_id, user_id, side, stake, auto_cashout, key) do
    GenServer.call(__MODULE__, {:debit_and_place, round_id, user_id, side, stake, auto_cashout, key})
  end
  def refund(bet, key) do
    GenServer.call(__MODULE__, {:refund, bet, key})
  end
  def credit_win(user_id, amount) do
    GenServer.call(__MODULE__, {:credit_win, user_id, amount})
  end
  def record_loss(bet) do
    GenServer.call(__MODULE__, {:record_loss, bet})
  end

  @impl true
  def init(_), do: {:ok, %{}}

  @impl true
  def handle_call({:debit_and_place, round_id, user_id, side, stake, auto_cashout, key}, _from, state) do
    cache_key = "idemp:#{key}"
    case Cachex.get(:talon_cache, cache_key) do
      {:ok, nil} ->
        balance = get_balance(user_id)
        if balance < stake do
          {:reply, {:error, "insufficient_balance"}, state}
        else
          Cachex.put(:talon_cache, cache_key, "debited", ttl: :timer.seconds(@idempotency_ttl))
          set_balance(user_id, balance - stake)
          bet = %Bet{round_id: round_id, user_id: user_id, side: side, stake: stake,
                     auto_cashout: auto_cashout, idempotency_key: key, status: "pending"}
          Task.start(fn -> Repo.insert(bet) end)
          {:reply, {:ok, bet}, state}
        end
      {:ok, _} ->
        {:reply, {:error, "duplicate_key"}, state}
    end
  end

  def handle_call({:refund, bet, key}, _from, state) do
    Cachex.del(:talon_cache, "idemp:#{key}")
    balance = get_balance(bet.user_id)
    set_balance(bet.user_id, balance + bet.stake)
    Task.start(fn ->
      Repo.get_by(Bet, idempotency_key: key)
      |> Ecto.Changeset.change(status: "cancelled")
      |> Repo.update()
    end)
    {:reply, :ok, state}
  end

  def handle_call({:credit_win, user_id, amount}, _from, state) do
    balance = get_balance(user_id)
    set_balance(user_id, balance + amount)
    {:reply, :ok, state}
  end

  def handle_call({:record_loss, bet}, _from, state) do
    Task.start(fn ->
      Repo.get_by(Bet, idempotency_key: bet.idempotency_key)
      |> Ecto.Changeset.change(status: "lost")
      |> Repo.update()
    end)
    {:reply, :ok, state}
  end

  defp get_balance(user_id) do
    case Cachex.get(:talon_cache, "bal:#{user_id}") do
      {:ok, nil} -> 1000.0
      {:ok, bal} -> bal
    end
  end

  defp set_balance(user_id, amount) do
    Cachex.put(:talon_cache, "bal:#{user_id}", Float.floor(amount * 100) / 100)
  end
end
