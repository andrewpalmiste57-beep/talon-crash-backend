defmodule TalonWeb.Endpoint do
  use Phoenix.Endpoint, otp_app: :talon

  socket "/socket", TalonWeb.UserSocket,
    websocket: [
      connect_info: [:peer_data, :x_headers],
      timeout: 60_000,
      transport_log: :debug,
      check_origin: false,
      compress: true
    ],
    longpoll: false

  plug Plug.Static, at: "/", from: :talon, gzip: true
  plug Plug.RequestId
  plug Plug.Telemetry, event_prefix: [:phoenix, :endpoint]
  plug Plug.Parsers, parsers: [:urlencoded, :multipart, :json], pass: ["*/*"], json_decoder: Phoenix.json_library()
  plug Plug.MethodOverride
  plug Plug.Head
  plug CORSPlug, origin: ["*"], methods: ["GET", "POST", "OPTIONS"]
  plug TalonWeb.Router
end
