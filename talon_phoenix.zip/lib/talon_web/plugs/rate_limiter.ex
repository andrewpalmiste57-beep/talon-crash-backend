defmodule TalonWeb.Plugs.RateLimiter do
  @moduledoc "Redis-backed rate limiter."
  import Plug.Conn
  require Logger

  def init(opts), do: opts

  def call(conn, _opts) do
    ip = conn.remote_ip |> :inet.ntoa() |> to_string()
    key = "rate:#{ip}"
    case ExRated.check_rate(key, 10_000, 5) do
      {:ok, _} -> conn
      {:error, _} ->
        conn
        |> put_resp_content_type("application/json")
        |> send_resp(429, Jason.encode!(%{error: "rate_limited"}))
        |> halt()
    end
  end
end
