defmodule TalonWeb.Gettext do
  use Gettext, otp_app: :talon
end
