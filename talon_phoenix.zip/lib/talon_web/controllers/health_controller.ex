defmodule TalonWeb.HealthController do
  use TalonWeb, :controller
  alias Talon.Game.{GameServer, CrashCalculator}

  def index(conn, _params) do
    json(conn, %{status: "ok", service: "talon", version: "3.2.0", time: System.system_time(:millisecond)})
  end

  def state(conn, _params) do
    json(conn, GameServer.state())
  end

  def verify_round(conn, %{"server_seed" => ss, "client_seed" => cs, "nonce" => n, "crash_point" => cp}) do
    valid = CrashCalculator.verify(ss, cs, String.to_integer(n), String.to_float(cp))
    json(conn, %{valid: valid, calculated: CrashCalculator.calculate(ss, cs, String.to_integer(n))})
  end
end
