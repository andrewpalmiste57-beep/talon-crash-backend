defmodule TalonWeb.UserSocket do
  use Phoenix.Socket
  channel "game:*", TalonWeb.GameChannel

  @impl true
  def connect(params, socket, _connect_info) do
    user_id = params["user_id"] || UUID.uuid4()
    {:ok, assign(socket, :user_id, user_id)}
  end

  @impl true
  def id(socket), do: "user_socket:#{socket.assigns.user_id}"
end
