defmodule TalonWeb.GameChannel do
  use TalonWeb, :channel
  require Logger
  alias Talon.Game.GameServer

  @heartbeat_ms 3_000

  @impl true
  def join("game:global", _payload, socket) do
    send(self(), :after_join)
    {:ok, assign(socket, :last_ping, System.monotonic_time(:millisecond))}
  end

  @impl true
  def handle_info(:after_join, socket) do
    push(socket, "state", GameServer.state())
    schedule_heartbeat()
    {:noreply, socket}
  end

  @impl true
  def handle_info(:heartbeat_check, socket) do
    now = System.monotonic_time(:millisecond)
    if now - socket.assigns.last_ping > 9_000 do
      {:stop, {:shutdown, :heartbeat_timeout}, socket}
    else
      schedule_heartbeat()
      {:noreply, socket}
    end
  end

  @impl true
  def handle_in("ping", %{"client_time" => ct}, socket) do
    {:reply, {:ok, %{client_time: ct, server_time: System.system_time(:millisecond)}}, socket}
  end

  def handle_in("bet.place", %{"side" => side, "stake" => stake, "autoCashout" => auto, "idempotencyKey" => key}, socket) do
    user_id = socket.assigns.user_id
    case GameServer.place_bet(user_id, side, stake, auto, key) do
      {:ok, bet} -> {:reply, {:ok, %{status: "accepted", bet: bet}}, socket}
      {:error, reason} -> {:reply, {:error, %{reason: reason}}, socket}
    end
  end

  def handle_in("bet.cancel", %{"side" => side, "idempotencyKey" => key}, socket) do
    user_id = socket.assigns.user_id
    case GameServer.cancel_bet(user_id, side, key) do
      :ok -> {:reply, {:ok, %{status: "cancelled"}}, socket}
      {:error, reason} -> {:reply, {:error, %{reason: reason}}, socket}
    end
  end

  def handle_in("bet.cashout", %{"side" => side}, socket) do
    user_id = socket.assigns.user_id
    case GameServer.cash_out(user_id, side) do
      {:ok, result} -> {:reply, {:ok, result}, socket}
      {:error, reason} -> {:reply, {:error, %{reason: reason}}, socket}
    end
  end

  def handle_in("pong", _payload, socket) do
    {:noreply, assign(socket, :last_ping, System.monotonic_time(:millisecond))}
  end

  defp schedule_heartbeat do
    Process.send_after(self(), :heartbeat_check, @heartbeat_ms)
  end
end
