defmodule TalonWeb.Router do
  use TalonWeb, :router

  pipeline :api do
    plug :accepts, ["json"]
    plug TalonWeb.Plugs.RateLimiter
  end

  scope "/api", TalonWeb do
    pipe_through :api
    get "/health", HealthController, :index
    get "/state", HealthController, :state
    get "/verify", HealthController, :verify_round
  end
end
