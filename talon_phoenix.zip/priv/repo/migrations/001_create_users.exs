defmodule Talon.Repo.Migrations.CreateUsers do
  use Ecto.Migration
  def change do
    create table(:users) do
      add :username, :string, null: false
      add :email, :string, null: false
      add :encrypted_password, :string
      add :balance, :decimal, precision: 18, scale: 2, default: 1000.00
      add :role, :string, default: "player"
      timestamps(type: :utc_datetime_usec)
    end
    create unique_index(:users, [:username])
    create unique_index(:users, [:email])
  end
end
