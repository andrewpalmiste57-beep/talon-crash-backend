defmodule Talon.Repo.Migrations.CreateBets do
  use Ecto.Migration
  def change do
    create table(:bets) do
      add :round_id, :bigint, null: false
      add :user_id, :string, null: false
      add :side, :string, null: false
      add :stake, :float, null: false
      add :auto_cashout, :float, default: 0
      add :cashed_out_at, :float
      add :payout, :float
      add :idempotency_key, :string, null: false
      add :status, :string, default: "pending"
      timestamps(type: :utc_datetime_usec)
    end
    create unique_index(:bets, [:idempotency_key])
    create index(:bets, [:round_id])
    create index(:bets, [:user_id])
  end
end
