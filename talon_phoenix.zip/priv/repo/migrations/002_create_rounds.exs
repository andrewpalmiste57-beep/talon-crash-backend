defmodule Talon.Repo.Migrations.CreateRounds do
  use Ecto.Migration
  def change do
    create table(:rounds) do
      add :round_number, :bigint, null: false
      add :server_seed_hash, :string, null: false
      add :server_seed, :string
      add :client_seed, :string
      add :nonce, :integer
      add :crash_point, :float, null: false
      add :started_at, :utc_datetime_usec
      add :crashed_at, :utc_datetime_usec
      add :total_bets, :integer, default: 0
      add :total_wagered, :decimal, precision: 18, scale: 2, default: 0
      add :total_payout, :decimal, precision: 18, scale: 2, default: 0
      timestamps(type: :utc_datetime_usec)
    end
    create unique_index(:rounds, [:round_number])
    create index(:rounds, [:server_seed_hash])
  end
end
