const { v4: uuidv4 } = require('uuid');
const { pool } = require('../db/Database');

// In-memory balance cache (use Redis in production)
const balances = new Map();
const idempotency = new Map();

class BetProcessor {
  getBalance(userId) {
    if (!balances.has(userId)) balances.set(userId, 1000.0);
    return balances.get(userId);
  }

  setBalance(userId, amount) {
    balances.set(userId, Math.floor(amount * 100) / 100);
  }

  debitAndPlace(roundId, userId, side, stake, autoCashout, key) {
    if (idempotency.has(key)) {
      return { ok: false, error: 'duplicate_key' };
    }
    const balance = this.getBalance(userId);
    if (balance < stake) {
      return { ok: false, error: 'insufficient_balance' };
    }
    idempotency.set(key, true);
    setTimeout(() => idempotency.delete(key), 300000); // 5 min TTL

    this.setBalance(userId, balance - stake);
    const bet = {
      id: uuidv4(),
      round_id: roundId,
      user_id: userId,
      side,
      stake,
      auto_cashout: autoCashout,
      cashed_out_at: null,
      payout: null,
      idempotency_key: key,
      status: 'pending'
    };

    // Async persist
    pool.query(
      `INSERT INTO bets (round_id, user_id, side, stake, auto_cashout, idempotency_key, status, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,NOW())`,
      [roundId, userId, side, stake, autoCashout, key, 'pending']
    ).catch(() => {});

    return { ok: true, bet };
  }

  refund(bet, key) {
    idempotency.delete(key);
    const balance = this.getBalance(bet.user_id);
    this.setBalance(bet.user_id, balance + bet.stake);
    pool.query(`UPDATE bets SET status='cancelled' WHERE idempotency_key=$1`, [key]).catch(() => {});
  }

  creditWin(userId, amount) {
    const balance = this.getBalance(userId);
    this.setBalance(userId, balance + amount);
  }

  recordLoss(bet) {
    pool.query(`UPDATE bets SET status='lost' WHERE idempotency_key=$1`, [bet.idempotency_key]).catch(() => {});
  }
}

module.exports = BetProcessor;
