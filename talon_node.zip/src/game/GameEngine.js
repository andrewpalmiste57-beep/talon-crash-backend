const crypto = require('crypto');
const EventEmitter = require('events');
const BetProcessor = require('../bets/BetProcessor');

const BETTING_MS = 10000;
const CRASH_DISPLAY_MS = 3000;
const GROWTH_RATE = 0.06;
const SYNC_INTERVAL_MS = 250;

class GameEngine extends EventEmitter {
  constructor(socketManager) {
    super();
    this.socketManager = socketManager;
    this.betProcessor = new BetProcessor();
    this.roundId = 0;
    this.phase = 'idle';
    this.serverSeed = null;
    this.serverSeedHash = null;
    this.clientSeed = process.env.TALON_CLIENT_SEED || this.generateSeed();
    this.crashPoint = 1.0;
    this.startTime = 0;
    this.bets = new Map();
    this.jackpot = 1250340.50;
    this.timers = {};
  }

  start() {
    this.startRound();
  }

  stop() {
    Object.values(this.timers).forEach(t => clearTimeout(t));
  }

  startRound() {
    this.roundId++;
    this.serverSeed = this.generateSeed();
    this.serverSeedHash = this.hashSeed(this.serverSeed);
    this.crashPoint = this.calculateCrash(this.serverSeed, this.clientSeed, this.roundId);
    this.phase = 'betting';
    this.bets.clear();
    this.startTime = Date.now();

    this.broadcast('round.start', {
      round_id: this.roundId,
      server_time: this.startTime,
      server_seed_hash: this.serverSeedHash,
      betting_duration: BETTING_MS,
      phase: 'betting'
    });

    this.timers.betting = setTimeout(() => this.startFlying(), BETTING_MS);
  }

  startFlying() {
    this.phase = 'flying';
    this.startTime = Date.now();
    const flightDuration = Math.log(this.crashPoint) / GROWTH_RATE * 1000;

    this.broadcast('round.flying', {
      round_id: this.roundId,
      server_time: this.startTime,
      phase: 'flying'
    });

    this.timers.flight = setTimeout(() => this.doCrash(), flightDuration);
    this.timers.sync = setInterval(() => this.syncTick(), SYNC_INTERVAL_MS);
  }

  syncTick() {
    if (this.phase !== 'flying') return;
    const elapsed = (Date.now() - this.startTime) / 1000;
    const multiplier = Math.exp(GROWTH_RATE * elapsed);
    this.broadcast('round.sync', {
      round_id: this.roundId,
      server_time: Date.now(),
      multiplier: Math.floor(multiplier * 100) / 100,
      elapsed_ms: elapsed * 1000
    });
  }

  doCrash() {
    this.phase = 'crashed';
    clearInterval(this.timers.sync);

    // Auto cashouts
    for (const [key, bet] of this.bets) {
      if (!bet.cashedOutAt && bet.autoCashout >= 1.01 && this.crashPoint >= bet.autoCashout) {
        const payout = Math.floor(bet.stake * bet.autoCashout * 100) / 100;
        this.betProcessor.creditWin(bet.userId, payout);
        bet.cashedOutAt = bet.autoCashout;
        bet.payout = payout;
        this.broadcast('cash_out', {
          user_id: bet.userId, side: bet.side,
          multiplier: bet.autoCashout, payout, auto: true
        });
      }
    }

    // Record losses
    for (const bet of this.bets.values()) {
      if (!bet.cashedOutAt) {
        this.betProcessor.recordLoss(bet);
      }
    }

    this.broadcast('round.crash', {
      round_id: this.roundId,
      crash_point: this.crashPoint,
      server_seed: this.serverSeed,
      server_time: Date.now()
    });

    this.jackpot += Math.floor(Math.random() * 50);
    this.timers.next = setTimeout(() => this.startRound(), CRASH_DISPLAY_MS);
  }

  placeBet(userId, payload) {
    if (this.phase !== 'betting') {
      this.sendTo(userId, 'bet.error', { reason: 'betting_closed' });
      return;
    }
    const { side, stake, autoCashout, idempotencyKey } = payload;
    const result = this.betProcessor.debitAndPlace(this.roundId, userId, side, stake, autoCashout, idempotencyKey);
    if (result.ok) {
      this.bets.set(`${userId}:${side}`, result.bet);
      this.broadcast('bet_placed', { user_id: userId, side, stake });
      this.sendTo(userId, 'bet.accepted', { bet: result.bet });
    } else {
      this.sendTo(userId, 'bet.error', { reason: result.error });
    }
  }

  cancelBet(userId, payload) {
    if (this.phase !== 'betting') {
      this.sendTo(userId, 'bet.error', { reason: 'cannot_cancel' });
      return;
    }
    const key = `${userId}:${payload.side}`;
    const bet = this.bets.get(key);
    if (!bet) {
      this.sendTo(userId, 'bet.error', { reason: 'no_bet' });
      return;
    }
    this.betProcessor.refund(bet, payload.idempotencyKey);
    this.bets.delete(key);
    this.broadcast('bet_cancelled', { user_id: userId, side: payload.side, refund: bet.stake });
    this.sendTo(userId, 'bet.cancelled', { status: 'cancelled' });
  }

  cashOut(userId, payload) {
    if (this.phase !== 'flying') {
      this.sendTo(userId, 'bet.error', { reason: 'not_flying' });
      return;
    }
    const key = `${userId}:${payload.side}`;
    const bet = this.bets.get(key);
    if (!bet || bet.cashedOutAt) {
      this.sendTo(userId, 'bet.error', { reason: bet ? 'already_cashed' : 'no_bet' });
      return;
    }
    const elapsed = (Date.now() - this.startTime) / 1000;
    const multiplier = Math.exp(GROWTH_RATE * elapsed);
    const payout = Math.floor(bet.stake * multiplier * 100) / 100;
    this.betProcessor.creditWin(userId, payout);
    bet.cashedOutAt = multiplier;
    bet.payout = payout;
    this.broadcast('cash_out', { user_id: userId, side: payload.side, multiplier, payout });
    this.sendTo(userId, 'cashout.success', { multiplier, payout });
  }

  broadcast(event, payload) {
    this.socketManager.broadcast(JSON.stringify({ event, payload }));
  }

  sendTo(userId, event, payload) {
    this.socketManager.sendTo(userId, JSON.stringify({ event, payload }));
  }

  getState() {
    return {
      round_id: this.roundId,
      phase: this.phase,
      server_seed_hash: this.serverSeedHash,
      crash_point: this.phase === 'crashed' ? this.crashPoint : null,
      server_time: Date.now(),
      start_time: this.startTime,
      jackpot: Math.floor(this.jackpot * 100) / 100,
      players: this.socketManager.count()
    };
  }

  generateSeed() {
    return crypto.randomBytes(32).toString('hex');
  }

  hashSeed(seed) {
    return crypto.createHash('sha256').update(seed).digest('hex');
  }

  calculateCrash(serverSeed, clientSeed, nonce) {
    const hmac = crypto.createHmac('sha256', serverSeed).update(`${clientSeed}:${nonce}`).digest('hex');
    const int = parseInt(hmac.substring(0, 13), 16);
    const result = Math.pow(2, 52) / (int + 1);
    const crash = result * 0.99;
    return crash < 1.01 ? 1.00 : Math.floor(crash * 100) / 100;
  }
}

module.exports = GameEngine;
