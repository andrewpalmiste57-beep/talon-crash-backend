require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const helmet = require('helmet');
const winston = require('winston');

const GameEngine = require('./game/GameEngine');
const SocketManager = require('./websocket/SocketManager');
const HeartbeatManager = require('./websocket/HeartbeatManager');
const RateLimiter = require('./security/RateLimiter');
const { pool } = require('./db/Database');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [new winston.transports.Console()]
});

const app = express();
const server = http.createServer(app);

app.use(helmet());
app.use(cors({ origin: '*', methods: ['GET', 'POST', 'OPTIONS'] }));
app.use(express.json({ limit: '10kb' }));
app.use(RateLimiter.http);

// Health & state endpoints
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'talon-node', version: '3.2.0', time: Date.now() });
});

app.get('/api/state', (req, res) => {
  res.json(GameEngine.getState());
});

app.get('/api/verify', (req, res) => {
  const { server_seed, client_seed, nonce, crash_point } = req.query;
  const calc = GameEngine.calculateCrash(server_seed, client_seed, parseInt(nonce));
  res.json({ valid: Math.abs(calc - parseFloat(crash_point)) < 0.001, calculated: calc });
});

// WebSocket server
const wss = new WebSocket.Server({
  server,
  path: '/socket',
  perMessageDeflate: { zlibDeflateOptions: { chunkSize: 1024, memLevel: 7, level: 3 },
                       zlibInflateOptions: { chunkSize: 10 * 1024 },
                       clientNoContextTakeover: true, serverNoContextTakeover: true,
                       serverMaxWindowBits: 10, concurrencyLimit: 10 }
});

const socketManager = new SocketManager(wss);
const heartbeatManager = new HeartbeatManager(socketManager);
const gameEngine = new GameEngine(socketManager);

wss.on('connection', (ws, req) => {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  if (!RateLimiter.allowConnection(ip)) {
    ws.close(1008, 'rate_limited');
    return;
  }

  const userId = req.url.includes('user_id=')
    ? new URL(req.url, `http://${req.headers.host}`).searchParams.get('user_id')
    : require('uuid').v4();

  socketManager.add(ws, userId, ip);
  heartbeatManager.start(ws);

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data);
      handleMessage(ws, userId, msg);
    } catch (e) {
      ws.send(JSON.stringify({ event: 'error', payload: { reason: 'invalid_json' } }));
    }
  });

  ws.on('close', () => {
    socketManager.remove(ws);
    heartbeatManager.stop(ws);
  });

  ws.on('error', (err) => logger.error('WS error', { error: err.message, userId }));

  // Send initial state
  ws.send(JSON.stringify({ event: 'state', payload: GameEngine.getState() }));
});

function handleMessage(ws, userId, msg) {
  const { event, payload } = msg;

  switch (event) {
    case 'ping':
      ws.send(JSON.stringify({
        event: 'pong',
        payload: { client_time: payload.client_time, server_time: Date.now() }
      }));
      break;

    case 'bet.place':
      gameEngine.placeBet(userId, payload);
      break;

    case 'bet.cancel':
      gameEngine.cancelBet(userId, payload);
      break;

    case 'bet.cashout':
      gameEngine.cashOut(userId, payload);
      break;

    case 'pong':
      heartbeatManager.pong(ws);
      break;

    default:
      ws.send(JSON.stringify({ event: 'error', payload: { reason: 'unknown_event' } }));
  }
}

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  logger.info(`TALON Node server listening on port ${PORT}`);
  gameEngine.start();
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  gameEngine.stop();
  server.close(() => {
    pool.end();
    process.exit(0);
  });
});
