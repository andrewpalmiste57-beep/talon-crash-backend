class SocketManager {
  constructor(wss) {
    this.wss = wss;
    this.clients = new Map(); // ws -> { userId, ip }
    this.userSockets = new Map(); // userId -> Set<ws>
  }

  add(ws, userId, ip) {
    this.clients.set(ws, { userId, ip, connectedAt: Date.now() });
    if (!this.userSockets.has(userId)) this.userSockets.set(userId, new Set());
    this.userSockets.get(userId).add(ws);
  }

  remove(ws) {
    const info = this.clients.get(ws);
    if (!info) return;
    this.clients.delete(ws);
    const set = this.userSockets.get(info.userId);
    if (set) {
      set.delete(ws);
      if (set.size === 0) this.userSockets.delete(info.userId);
    }
  }

  broadcast(data) {
    this.wss.clients.forEach(ws => {
      if (ws.readyState === 1) {
        try { ws.send(data); } catch (e) {}
      }
    });
  }

  sendTo(userId, data) {
    const set = this.userSockets.get(userId);
    if (!set) return;
    set.forEach(ws => {
      if (ws.readyState === 1) {
        try { ws.send(data); } catch (e) {}
      }
    });
  }

  count() {
    return this.clients.size;
  }
}

module.exports = SocketManager;
