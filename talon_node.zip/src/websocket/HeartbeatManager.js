const HEARTBEAT_INTERVAL = 3000;
const HEARTBEAT_TIMEOUT = 9000;

class HeartbeatManager {
  constructor(socketManager) {
    this.socketManager = socketManager;
    this.heartbeats = new Map(); // ws -> { lastPong, timer }
  }

  start(ws) {
    const check = () => {
      const hb = this.heartbeats.get(ws);
      if (!hb) return;
      if (Date.now() - hb.lastPong > HEARTBEAT_TIMEOUT) {
        ws.terminate();
        this.stop(ws);
        return;
      }
      if (ws.readyState === 1) {
        try { ws.send(JSON.stringify({ event: 'ping', payload: { server_time: Date.now() } })); } catch (e) {}
      }
      hb.timer = setTimeout(check, HEARTBEAT_INTERVAL);
    };

    this.heartbeats.set(ws, { lastPong: Date.now(), timer: setTimeout(check, HEARTBEAT_INTERVAL) });
  }

  pong(ws) {
    const hb = this.heartbeats.get(ws);
    if (hb) hb.lastPong = Date.now();
  }

  stop(ws) {
    const hb = this.heartbeats.get(ws);
    if (hb) {
      clearTimeout(hb.timer);
      this.heartbeats.delete(ws);
    }
  }
}

module.exports = HeartbeatManager;
