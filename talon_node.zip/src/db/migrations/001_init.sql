CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  encrypted_password VARCHAR(255),
  balance DECIMAL(18,2) DEFAULT 1000.00,
  role VARCHAR(50) DEFAULT 'player',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS rounds (
  id SERIAL PRIMARY KEY,
  round_number BIGINT UNIQUE NOT NULL,
  server_seed_hash VARCHAR(255) NOT NULL,
  server_seed VARCHAR(255),
  client_seed VARCHAR(255),
  nonce INTEGER,
  crash_point FLOAT NOT NULL,
  started_at TIMESTAMPTZ,
  crashed_at TIMESTAMPTZ,
  total_bets INTEGER DEFAULT 0,
  total_wagered DECIMAL(18,2) DEFAULT 0,
  total_payout DECIMAL(18,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bets (
  id SERIAL PRIMARY KEY,
  round_id BIGINT NOT NULL,
  user_id VARCHAR(255) NOT NULL,
  side VARCHAR(10) NOT NULL,
  stake FLOAT NOT NULL,
  auto_cashout FLOAT DEFAULT 0,
  cashed_out_at FLOAT,
  payout FLOAT,
  idempotency_key VARCHAR(255) UNIQUE NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_bets_round ON bets(round_id);
CREATE INDEX idx_bets_user ON bets(user_id);
CREATE INDEX idx_rounds_hash ON rounds(server_seed_hash);
