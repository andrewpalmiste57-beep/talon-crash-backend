const { RateLimiterRedis } = require('rate-limiter-flexible');
const Redis = require('ioredis');

const redisClient = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

const connLimiter = new RateLimiterRedis({
  storeClient: redisClient,
  keyPrefix: 'talon_conn',
  points: 5,
  duration: 10
});

const betLimiter = new RateLimiterRedis({
  storeClient: redisClient,
  keyPrefix: 'talon_bet',
  points: 10,
  duration: 60
});

class RateLimiter {
  static http(req, res, next) {
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    connLimiter.consume(ip, 1)
      .then(() => next())
      .catch(() => res.status(429).json({ error: 'rate_limited' }));
  }

  static allowConnection(ip) {
    try {
      connLimiter.consume(ip, 1);
      return true;
    } catch {
      return false;
    }
  }

  static async allowBet(userId) {
    try {
      await betLimiter.consume(userId, 1);
      return true;
    } catch {
      return false;
    }
  }
}

module.exports = RateLimiter;
