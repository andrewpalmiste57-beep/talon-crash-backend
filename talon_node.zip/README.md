# TALON Crash Game — Node.js Backend

## Deploy

### AWS Elastic Beanstalk
```bash
ebp init -p node.js talon-crash-game
ebp create
ebp deploy
```
Make sure `.ebextensions/websocket.config` is included for WebSocket support.

### Render
```bash
# Connect GitHub repo, uses Dockerfile
```

### Local
```bash
npm install
npm start
```

### Docker
```bash
docker-compose up --build
```

## Env Vars
- `DATABASE_URL` — Postgres connection string
- `REDIS_URL` — Redis connection string
- `SECRET_KEY_BASE` — JWT secret
- `TALON_CLIENT_SEED` — Fixed client seed
- `PORT` — Server port (default 4000)

## WebSocket
`wss://HOST/socket?user_id=UUID`

## Protocol
Same as Phoenix backend. Join and listen for `round.start`, `round.flying`, `round.sync`, `round.crash`.
Send `bet.place`, `bet.cancel`, `bet.cashout`, `ping`.

## Provably Fair
Same HMAC-SHA256 algorithm. Verify via `/api/verify`.
