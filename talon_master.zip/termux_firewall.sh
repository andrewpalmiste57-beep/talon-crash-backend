#!/data/data/com.termux/files/usr/bin/bash
# TALON Termux Firewall Hardening
# Run as root or with tsu

echo "[TALON] Applying firewall rules..."

# Flush existing
iptables -F
iptables -X

# Default drop
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# Allow loopback
iptables -A INPUT -i lo -j ACCEPT

# Allow established connections
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Allow Phoenix WS/API from localhost only
iptables -A INPUT -p tcp --dport 4000 -s 127.0.0.1 -j ACCEPT
iptables -A INPUT -p tcp --dport 4000 -j DROP

# Block Postgres external access
iptables -A INPUT -p tcp --dport 5432 -j DROP

# Allow SSH if needed (optional, comment out if not using)
# iptables -A INPUT -p tcp --dport 8022 -j ACCEPT

echo "[TALON] Firewall active."
iptables -L -n
