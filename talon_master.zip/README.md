# TALON Crash Game Backend v3.2

Elixir Phoenix backend for the Warp Vortex crash game.

## Quick Start (Termux)

```bash
cd ~/talon
mix deps.get
mix compile
mix ecto.migrate
mix phx.server
```

WebSocket: `ws://localhost:4000/socket`  
Channel: `crash_game:<room_id>`  
Health: `http://localhost:4000/api/health`

## Architecture

- **ProvablyFair** — SHA-256 seed commitment + crash point calculation
- **RoundEngine** — Game loop: waiting → active → crashed
- **BetLedger** — In-memory ledger with cryptographic nonces
- **CashoutGuardian** — Atomic validation prevents ghost/race cashouts
- **RateLimiter** — Per-user and global rate limiting

## Docker

```bash
docker compose up --build
```

## Render Deploy

1. Push repo with `Dockerfile` and `render.yaml`
2. Connect Render Blueprint
3. Auto-deploys on push

## Files Included

```
talon_master/
├── talon_phoenix/          # Full Phoenix project
│   ├── lib/talon/          # 5 GenServers
│   ├── lib/talon_web/      # Channels, controllers, plugs
│   ├── priv/repo/migrations/  # 6 migrations + RLS
│   └── config/             # dev/prod/runtime configs
├── Dockerfile              # Production Elixir release
├── docker-compose.yml      # Local orchestration
├── render.yaml             # Render Blueprint (no npm)
├── termux_deploy.sh        # Termux convenience script
├── .github/workflows/      # CI/CD pipeline
├── SECURITY_HARDENING.md   # Threat model & mitigations
└── README.md               # This file
```
