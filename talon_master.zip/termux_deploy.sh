#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "=== TALON PHOENIX DEPLOYMENT ==="
echo "Step 1: Getting dependencies..."
cd ~/talon
mix deps.get

echo "Step 2: Compiling..."
mix compile

echo "Step 3: Running migrations..."
mix ecto.migrate

echo "Step 4: Starting server..."
echo "TALON is live at ws://localhost:4000/socket"
mix phx.server
