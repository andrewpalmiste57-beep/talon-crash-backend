defmodule Talon.Repo.Migrations.CreateBets do
  use Ecto.Migration

  def change do
    create table(:bets, primary_key: false) do
      add :id, :uuid, primary_key: true
      add :user_id, :string, null: false
      add :amount, :decimal, precision: 18, scale: 8, null: false
      add :auto_cashout, :decimal, precision: 10, scale: 2
      add :currency, :string, null: false, default: "USD"
      add :status, :string, null: false, default: "pending"
      add :session_id, :string, null: false
      add :round_id, references(:rounds, type: :uuid, on_delete: :nilify_all)
      timestamps(type: :utc_datetime_usec)
    end

    create index(:bets, [:user_id])
    create index(:bets, [:round_id])
    create index(:bets, [:session_id])
    create index(:bets, [:status])
    create unique_index(:bets, [:user_id, :session_id, :round_id], name: :bets_user_session_round_unique)
  end
end
