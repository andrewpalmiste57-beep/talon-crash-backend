defmodule Talon.Repo.Migrations.CreateRounds do
  use Ecto.Migration

  def change do
    create table(:rounds, primary_key: false) do
      add :id, :uuid, primary_key: true
      add :seed, :string, null: false
      add :hash, :string, null: false
      add :crash_point, :decimal, precision: 10, scale: 2, null: false
      add :status, :string, null: false, default: "waiting"
      add :started_at, :utc_datetime_usec
      add :ended_at, :utc_datetime_usec
      timestamps(type: :utc_datetime_usec)
    end

    create index(:rounds, [:status])
    create index(:rounds, [:started_at])
  end
end
