defmodule Talon.Repo.Migrations.CreateCashouts do
  use Ecto.Migration

  def change do
    create table(:cashouts, primary_key: false) do
      add :id, :uuid, primary_key: true
      add :multiplier, :decimal, precision: 10, scale: 2, null: false
      add :payout, :decimal, precision: 18, scale: 8, null: false
      add :cashout_at, :utc_datetime_usec, null: false
      add :bet_id, references(:bets, type: :uuid, on_delete: :delete_all), null: false
      timestamps(type: :utc_datetime_usec)
    end

    create index(:cashouts, [:bet_id])
    create index(:cashouts, [:cashout_at])
  end
end
