defmodule Talon.Repo.Migrations.EnableRls do
  use Ecto.Migration

  def up do
    execute "ALTER TABLE bets ENABLE ROW LEVEL SECURITY"
    execute "ALTER TABLE cashouts ENABLE ROW LEVEL SECURITY"
    execute "ALTER TABLE rounds ENABLE ROW LEVEL SECURITY"

    execute """
    CREATE POLICY bets_isolation ON bets
    USING (user_id = current_setting('app.current_user_id') OR current_setting('app.current_user_id') = 'admin');
    """

    execute """
    CREATE POLICY cashouts_isolation ON cashouts
    USING (EXISTS (
      SELECT 1 FROM bets b WHERE b.id = cashouts.bet_id
      AND (b.user_id = current_setting('app.current_user_id') OR current_setting('app.current_user_id') = 'admin')
    ));
    """

    execute """
    CREATE POLICY rounds_read_all ON rounds
    FOR SELECT USING (true);
    """
  end

  def down do
    execute "DROP POLICY IF EXISTS bets_isolation ON bets"
    execute "DROP POLICY IF EXISTS cashouts_isolation ON cashouts"
    execute "DROP POLICY IF EXISTS rounds_read_all ON rounds"
    execute "ALTER TABLE bets DISABLE ROW LEVEL SECURITY"
    execute "ALTER TABLE cashouts DISABLE ROW LEVEL SECURITY"
    execute "ALTER TABLE rounds DISABLE ROW LEVEL SECURITY"
  end
end
