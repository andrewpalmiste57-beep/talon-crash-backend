defmodule Talon.Repo.Migrations.AddAtomicCashoutFunction do
  use Ecto.Migration

  def up do
    execute """
    CREATE OR REPLACE FUNCTION atomic_cashout(
      p_bet_id UUID,
      p_multiplier DECIMAL,
      p_payout DECIMAL
    ) RETURNS TABLE(cashout_id UUID, success BOOLEAN) AS $$
    DECLARE
      v_bet_status VARCHAR;
      v_round_status VARCHAR;
      v_new_id UUID;
    BEGIN
      SELECT status INTO v_bet_status FROM bets WHERE id = p_bet_id FOR UPDATE;
      IF v_bet_status IS NULL THEN
        RETURN QUERY SELECT NULL::UUID, FALSE;
        RETURN;
      END IF;
      IF v_bet_status != 'active' THEN
        RETURN QUERY SELECT NULL::UUID, FALSE;
        RETURN;
      END IF;
      SELECT r.status INTO v_round_status
      FROM rounds r JOIN bets b ON b.round_id = r.id WHERE b.id = p_bet_id;
      IF v_round_status != 'active' THEN
        RETURN QUERY SELECT NULL::UUID, FALSE;
        RETURN;
      END IF;
      v_new_id := gen_random_uuid();
      INSERT INTO cashouts (id, multiplier, payout, cashout_at, bet_id, inserted_at, updated_at)
      VALUES (v_new_id, p_multiplier, p_payout, NOW(), p_bet_id, NOW(), NOW());
      UPDATE bets SET status = 'cashed_out', updated_at = NOW() WHERE id = p_bet_id;
      RETURN QUERY SELECT v_new_id, TRUE;
    END;
    $$ LANGUAGE plpgsql;
    """
  end

  def down do
    execute "DROP FUNCTION IF EXISTS atomic_cashout(UUID, DECIMAL, DECIMAL)"
  end
end
