defmodule Talon.Repo.Migrations.AddAutoCashoutTrigger do
  use Ecto.Migration

  def up do
    execute """
    CREATE OR REPLACE FUNCTION auto_cashout_trigger()
    RETURNS TRIGGER AS $$
    BEGIN
      IF NEW.status = 'active' AND (OLD.status IS NULL OR OLD.status = 'waiting') THEN
        PERFORM pg_notify('round_active', NEW.id::TEXT);
      END IF;
      RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;
    """

    execute """
    CREATE TRIGGER round_active_trigger
    AFTER UPDATE ON rounds
    FOR EACH ROW
    WHEN (OLD.status = 'waiting' AND NEW.status = 'active')
    EXECUTE FUNCTION auto_cashout_trigger();
    """
  end

  def down do
    execute "DROP TRIGGER IF EXISTS round_active_trigger ON rounds"
    execute "DROP FUNCTION IF EXISTS auto_cashout_trigger()"
  end
end
