# Talon seeds
alias Talon.Repo

IO.puts("Seeds loaded.")
