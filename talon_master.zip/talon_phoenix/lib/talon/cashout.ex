defmodule Talon.Cashout do
  use Ecto.Schema
  import Ecto.Changeset

  @primary_key {:id, :binary_id, autogenerate: true}
  schema "cashouts" do
    field :multiplier, :decimal
    field :payout, :decimal
    field :cashout_at, :utc_datetime_usec
    belongs_to :bet, Talon.Bet, type: :binary_id
    timestamps(type: :utc_datetime_usec)
  end

  def changeset(cashout, attrs) do
    cashout
    |> cast(attrs, [:multiplier, :payout, :cashout_at, :bet_id])
    |> validate_required([:multiplier, :payout, :cashout_at, :bet_id])
    |> validate_number(:multiplier, greater_than: 1.0)
  end
end
