defmodule Talon.Round do
  use Ecto.Schema
  import Ecto.Changeset

  @primary_key {:id, :binary_id, autogenerate: true}
  schema "rounds" do
    field :seed, :string
    field :hash, :string
    field :crash_point, :decimal
    field :status, :string, default: "waiting"
    field :started_at, :utc_datetime_usec
    field :ended_at, :utc_datetime_usec
    has_many :bets, Talon.Bet
    timestamps(type: :utc_datetime_usec)
  end

  def changeset(round, attrs) do
    round
    |> cast(attrs, [:seed, :hash, :crash_point, :status, :started_at, :ended_at])
    |> validate_required([:seed, :hash, :crash_point, :status])
    |> validate_inclusion(:status, ["waiting", "active", "crashed", "settled"])
  end
end
