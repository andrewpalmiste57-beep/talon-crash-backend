defmodule Talon.Bet do
  use Ecto.Schema
  import Ecto.Changeset

  @primary_key {:id, :binary_id, autogenerate: true}
  schema "bets" do
    field :user_id, :string
    field :amount, :decimal
    field :auto_cashout, :decimal
    field :currency, :string, default: "USD"
    field :status, :string, default: "pending"
    field :session_id, :string
    belongs_to :round, Talon.Round, type: :binary_id
    has_one :cashout, Talon.Cashout
    timestamps(type: :utc_datetime_usec)
  end

  def changeset(bet, attrs) do
    bet
    |> cast(attrs, [:user_id, :amount, :auto_cashout, :currency, :status, :session_id, :round_id])
    |> validate_required([:user_id, :amount, :currency, :status, :session_id])
    |> validate_inclusion(:status, ["pending", "active", "cashed_out", "lost"])
    |> validate_number(:amount, greater_than: 0)
  end
end
