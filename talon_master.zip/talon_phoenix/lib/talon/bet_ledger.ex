defmodule Talon.BetLedger do
  @moduledoc "Tracks all bets and enforces ledger integrity."
  use GenServer
  require Logger

  def start_link(opts \\ []) do
    GenServer.start_link(__MODULE__, :ok, name: __MODULE__)
  end

  def record_bet(user_id, round_id, amount, metadata \\ %{}) do
    GenServer.call(__MODULE__, {:record_bet, user_id, round_id, amount, metadata})
  end

  def get_user_bets(user_id, limit \\ 50) do
    GenServer.call(__MODULE__, {:get_user_bets, user_id, limit})
  end

  @impl true
  def init(:ok) do
    {:ok, %{ledger: %{}, nonces: %{}}}
  end

  @impl true
  def handle_call({:record_bet, user_id, round_id, amount, metadata}, _from, state) do
    nonce = System.unique_integer([:positive])
    entry = %{
      user_id: user_id, round_id: round_id,
      amount: Decimal.new(amount), nonce: nonce,
      metadata: metadata, recorded_at: DateTime.utc_now()
    }
    user_ledger = Map.get(state.ledger, user_id, [])
    new_ledger = Map.put(state.ledger, user_id, [entry | user_ledger])
    new_nonces = Map.put(state.nonces, nonce, true)
    {:reply, {:ok, nonce}, %{state | ledger: new_ledger, nonces: new_nonces}}
  end

  @impl true
  def handle_call({:get_user_bets, user_id, limit}, _from, state) do
    bets = state.ledger |> Map.get(user_id, []) |> Enum.take(limit)
    {:reply, bets, state}
  end
end
