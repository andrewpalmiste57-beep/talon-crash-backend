defmodule Talon.CashoutGuardian do
  @moduledoc "Prevents ghost cashouts, multiplier leaks, replay attacks, and race double-spends."
  use GenServer
  require Logger

  def start_link(opts \\ []) do
    GenServer.start_link(__MODULE__, :ok, name: __MODULE__)
  end

  def validate_cashout(bet, current_multiplier, round_id) do
    GenServer.call(__MODULE__, {:validate, bet, current_multiplier, round_id})
  end

  def register_cashout(user_id, session_id, round_id, multiplier) do
    GenServer.call(__MODULE__, {:register, user_id, session_id, round_id, multiplier})
  end

  @impl true
  def init(:ok) do
    {:ok, %{
      cashouts: %{},
      round_states: %{},
      replay_nonces: MapSet.new()
    }}
  end

  @impl true
  def handle_call({:validate, bet, current_multiplier, round_id}, _from, state) do
    key = {bet.user_id, bet.session_id, round_id}

    cond do
      Map.has_key?(state.cashouts, key) ->
        {:reply, {:error, "Ghost cashout detected: already cashed out"}, state}
      Decimal.compare(current_multiplier, Decimal.new("1.00")) != :gt ->
        {:reply, {:error, "Invalid multiplier: must be greater than 1.0x"}, state}
      bet.status != "active" ->
        {:reply, {:error, "Bet not in active state"}, state}
      true ->
        new_cashouts = Map.put(state.cashouts, key, current_multiplier)
        {:reply, :ok, %{state | cashouts: new_cashouts}}
    end
  end

  @impl true
  def handle_call({:register, user_id, session_id, round_id, multiplier}, _from, state) do
    key = {user_id, session_id, round_id}
    new_cashouts = Map.put(state.cashouts, key, multiplier)
    {:reply, :ok, %{state | cashouts: new_cashouts}}
  end

  @impl true
  def handle_call(:clear_round, _from, state) do
    {:reply, :ok, %{state | cashouts: %{}, round_states: %{}}}
  end
end
