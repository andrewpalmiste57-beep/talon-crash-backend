defmodule Talon.ProvablyFair do
  @moduledoc "Generates cryptographically secure seeds and verifies fairness."
  use GenServer
  require Logger

  @hash_algorithm :sha256

  def start_link(opts \\ []) do
    GenServer.start_link(__MODULE__, :ok, name: __MODULE__)
  end

  def generate_round_seed do
    GenServer.call(__MODULE__, :generate_seed)
  end

  def verify(seed, hash) do
    GenServer.call(__MODULE__, {:verify, seed, hash})
  end

  def calculate_crash_point(server_seed, client_seed \\ "talon_default_client") do
    GenServer.call(__MODULE__, {:calculate_crash, server_seed, client_seed})
  end

  @impl true
  def init(:ok) do
    {:ok, %{}}
  end

  @impl true
  def handle_call(:generate_seed, _from, state) do
    seed = :crypto.strong_rand_bytes(32) |> Base.encode16(case: :lower)
    hash = :crypto.hash(@hash_algorithm, seed) |> Base.encode16(case: :lower)
    {:reply, %{seed: seed, hash: hash}, state}
  end

  @impl true
  def handle_call({:verify, seed, hash}, _from, state) do
    computed = :crypto.hash(@hash_algorithm, seed) |> Base.encode16(case: :lower)
    {:reply, computed == hash, state}
  end

  @impl true
  def handle_call({:calculate_crash, server_seed, client_seed}, _from, state) do
    combined = server_seed <> client_seed
    hash = :crypto.hash(@hash_algorithm, combined) |> Base.encode16(case: :lower)
    h = String.slice(hash, 0, 13)
    int = String.to_integer(h, 16)
    max = trunc(:math.pow(2, 52))
    ratio = int / max

    crash_point = if ratio < 0.01 do
      Decimal.new("1.00")
    else
      result = 0.99 / (1 - ratio)
      result = min(result, 1000.0)
      Decimal.from_float(result) |> Decimal.round(2)
    end

    {:reply, crash_point, state}
  end
end
