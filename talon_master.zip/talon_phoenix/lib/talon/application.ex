defmodule Talon.Application do
  @moduledoc false
  use Application

  @impl true
  def start(_type, _args) do
    children = [
      Talon.Repo,
      {Phoenix.PubSub, name: Talon.PubSub},
      TalonWeb.Endpoint,
      Talon.ProvablyFair,
      Talon.RoundEngine,
      Talon.BetLedger,
      Talon.CashoutGuardian,
      Talon.RateLimiter
    ]

    opts = [strategy: :one_for_one, name: Talon.Supervisor]
    Supervisor.start_link(children, opts)
  end

  @impl true
  def config_change(changed, _new, removed) do
    TalonWeb.Endpoint.config_change(changed, removed)
    :ok
  end
end
