defmodule Talon.RateLimiter do
  @moduledoc "Prevents abuse via rate limiting per user and global."
  use GenServer
  require Logger

  @bet_limit {5, 10_000}
  @cashout_limit {10, 5_000}
  @global_limit {100, 1_000}

  def start_link(opts \\ []) do
    GenServer.start_link(__MODULE__, :ok, name: __MODULE__)
  end

  def check_rate(user_id, action) do
    GenServer.call(__MODULE__, {:check, user_id, action})
  end

  @impl true
  def init(:ok) do
    {:ok, %{users: %{}, global: []}}
  end

  @impl true
  def handle_call({:check, user_id, action}, _from, state) do
    now = System.monotonic_time(:millisecond)
    state = %{state | global: clean_old(state.global, now, 1_000)}
    users = Map.update(state.users, user_id, %{}, fn user_map ->
      Map.update(user_map, action, [], fn entries ->
        clean_old(entries, now, elem(limit_for(action), 1))
      end)
    end)
    state = %{state | users: users}

    if length(state.global) >= elem(@global_limit, 0) do
      {:reply, {:error, "Global rate limit exceeded"}, state}
    else
      user_actions = get_in(state.users, [user_id, action]) || []
      {limit, window} = limit_for(action)
      if length(user_actions) >= limit do
        {:reply, {:error, "Rate limit exceeded for #{action}"}, state}
      else
        new_global = [now | state.global]
        new_user_actions = [now | user_actions]
        new_users = put_in(state.users, [user_id, action], new_user_actions)
        {:reply, :ok, %{state | global: new_global, users: new_users}}
      end
    end
  end

  defp clean_old(list, now, window) do
    Enum.filter(list, fn t -> now - t < window end)
  end

  defp limit_for(:bet), do: @bet_limit
  defp limit_for(:cashout), do: @cashout_limit
  defp limit_for(_), do: @global_limit
end
