defmodule Talon.RoundEngine do
  @moduledoc "Manages game rounds: waiting -> active -> crashed -> settled."
  use GenServer
  require Logger

  @tick_interval_ms 50
  @waiting_duration_ms 5_000
  @min_players 1

  def start_link(opts \\ []) do
    GenServer.start_link(__MODULE__, :ok, name: __MODULE__)
  end

  def current_state do
    GenServer.call(__MODULE__, :current_state)
  end

  def place_bet(user_id, amount, auto_cashout, session_id) do
    GenServer.call(__MODULE__, {:place_bet, user_id, amount, auto_cashout, session_id})
  end

  def cashout(user_id, session_id) do
    GenServer.call(__MODULE__, {:cashout, user_id, session_id})
  end

  defmodule State do
    defstruct [
      :round_id, :seed, :hash, :crash_point, :status,
      :started_at, :multiplier, :bets, :timer_ref, :tick_ref
    ]
  end

  @impl true
  def init(:ok) do
    schedule_new_round()
    {:ok, %State{status: "idle", multiplier: Decimal.new("1.00"), bets: %{}}}
  end

  @impl true
  def handle_call(:current_state, _from, state) do
    {:reply, serialize_state(state), state}
  end

  @impl true
  def handle_call({:place_bet, user_id, amount, auto_cashout, session_id}, _from, state) do
    if state.status in ["waiting", "idle"] do
      bet_key = {user_id, session_id}
      if Map.has_key?(state.bets, bet_key) do
        {:reply, {:error, "Already placed bet in this round"}, state}
      else
        case Talon.RateLimiter.check_rate(user_id, :bet) do
          :ok ->
            bet = %{
              user_id: user_id,
              amount: Decimal.new(amount),
              auto_cashout: if(auto_cashout, do: Decimal.new(auto_cashout), else: nil),
              session_id: session_id,
              status: "active"
            }
            bets = Map.put(state.bets, bet_key, bet)
            new_state = %{state | bets: bets}
            broadcast_state(new_state)
            {:reply, {:ok, "Bet placed"}, new_state}
          {:error, reason} ->
            {:reply, {:error, reason}, state}
        end
      end
    else
      {:reply, {:error, "Round not accepting bets"}, state}
    end
  end

  @impl true
  def handle_call({:cashout, user_id, session_id}, _from, state) do
    if state.status == "active" do
      bet_key = {user_id, session_id}
      case Map.get(state.bets, bet_key) do
        nil ->
          {:reply, {:error, "No active bet found"}, state}
        %{status: "cashed_out"} ->
          {:reply, {:error, "Already cashed out"}, state}
        bet ->
          case Talon.CashoutGuardian.validate_cashout(bet, state.multiplier, state.round_id) do
            :ok ->
              payout = Decimal.mult(bet.amount, state.multiplier) |> Decimal.round(2)
              updated_bet = %{bet | status: "cashed_out", payout: payout, cashout_multiplier: state.multiplier}
              bets = Map.put(state.bets, bet_key, updated_bet)
              new_state = %{state | bets: bets}
              Task.start(fn -> persist_cashout(state.round_id, bet, state.multiplier, payout) end)
              broadcast_state(new_state)
              {:reply, {:ok, %{multiplier: state.multiplier, payout: payout}}, new_state}
            {:error, reason} ->
              {:reply, {:error, reason}, state}
          end
      end
    else
      {:reply, {:error, "Round not active"}, state}
    end
  end

  @impl true
  def handle_info(:start_new_round, state) do
    %{seed: seed, hash: hash} = Talon.ProvablyFair.generate_round_seed()
    crash_point = Talon.ProvablyFair.calculate_crash_point(seed)
    round_id = Ecto.UUID.generate()

    Task.start(fn ->
      Talon.Repo.insert!(%Talon.Round{
        id: round_id, seed: seed, hash: hash,
        crash_point: crash_point, status: "waiting",
        started_at: DateTime.utc_now()
      })
    end)

    new_state = %State{
      round_id: round_id, seed: seed, hash: hash,
      crash_point: crash_point, status: "waiting",
      started_at: DateTime.utc_now(), multiplier: Decimal.new("1.00"),
      bets: %{},
      timer_ref: Process.send_after(self(), :activate_round, @waiting_duration_ms),
      tick_ref: nil
    }

    broadcast_state(new_state)
    {:noreply, new_state}
  end

  @impl true
  def handle_info(:activate_round, state) do
    if map_size(state.bets) >= @min_players do
      new_state = %{state | status: "active", started_at: DateTime.utc_now()}
      tick_ref = Process.send_after(self(), :tick, @tick_interval_ms)
      new_state = %{new_state | tick_ref: tick_ref}

      Task.start(fn ->
        Talon.Repo.get(Talon.Round, state.round_id)
        |> Ecto.Changeset.change(status: "active")
        |> Talon.Repo.update!()
      end)

      broadcast_state(new_state)
      {:noreply, new_state}
    else
      broadcast_state(%{state | status: "waiting_cancelled"})
      schedule_new_round()
      {:noreply, %State{status: "idle", multiplier: Decimal.new("1.00"), bets: %{}}}
    end
  end

  @impl true
  def handle_info(:tick, state) when state.status == "active" do
    elapsed_ms = DateTime.diff(DateTime.utc_now(), state.started_at, :millisecond)
    raw = :math.exp(0.00006 * elapsed_ms)
    multiplier = Decimal.from_float(raw) |> Decimal.round(2)

    {new_bets, auto_cashouts} = process_auto_cashouts(state.bets, multiplier, state.round_id)
    new_state = %{state | multiplier: multiplier, bets: new_bets}

    Enum.each(auto_cashouts, fn ac ->
      Phoenix.PubSub.broadcast(Talon.PubSub, "crash_game:global", {:auto_cashout, ac})
    end)

    if Decimal.compare(multiplier, state.crash_point) in [:gt, :eq] do
      crashed_state = %{new_state | status: "crashed", ended_at: DateTime.utc_now()}

      Task.start(fn ->
        Talon.Repo.get(Talon.Round, state.round_id)
        |> Ecto.Changeset.change(status: "crashed", ended_at: DateTime.utc_now())
        |> Talon.Repo.update!()
        settle_lost_bets(state.round_id, crashed_state.bets)
      end)

      broadcast_state(crashed_state)
      schedule_new_round()
      {:noreply, %State{status: "idle", multiplier: Decimal.new("1.00"), bets: %{}}}
    else
      tick_ref = Process.send_after(self(), :tick, @tick_interval_ms)
      new_state = %{new_state | tick_ref: tick_ref}
      broadcast_state(new_state)
      {:noreply, new_state}
    end
  end

  @impl true
  def handle_info(:tick, state), do: {:noreply, state}

  defp schedule_new_round, do: Process.send_after(self(), :start_new_round, 2_000)

  defp process_auto_cashouts(bets, multiplier, round_id) do
    Enum.reduce(bets, {bets, []}, fn {key, bet}, {acc_bets, acc_cashouts} ->
      if bet.status == "active" and bet.auto_cashout != nil and
         Decimal.compare(multiplier, bet.auto_cashout) != :lt do
        payout = Decimal.mult(bet.amount, multiplier) |> Decimal.round(2)
        updated = %{bet | status: "cashed_out", payout: payout, cashout_multiplier: multiplier}
        Task.start(fn -> persist_cashout(round_id, bet, multiplier, payout) end)
        {Map.put(acc_bets, key, updated),
         [%{user_id: bet.user_id, session_id: bet.session_id, multiplier: multiplier, payout: payout} | acc_cashouts]}
      else
        {acc_bets, acc_cashouts}
      end
    end)
  end

  defp persist_cashout(round_id, bet, multiplier, payout) do
    bet_record = case Talon.Repo.get_by(Talon.Bet, user_id: bet.user_id, session_id: bet.session_id, round_id: round_id) do
      nil ->
        Talon.Repo.insert!(%Talon.Bet{
          id: Ecto.UUID.generate(), user_id: bet.user_id, amount: bet.amount,
          auto_cashout: bet.auto_cashout, session_id: bet.session_id,
          round_id: round_id, status: "cashed_out"
        })
      existing -> existing
    end

    Talon.Repo.insert!(%Talon.Cashout{
      id: Ecto.UUID.generate(), bet_id: bet_record.id,
      multiplier: multiplier, payout: payout, cashout_at: DateTime.utc_now()
    })
  end

  defp settle_lost_bets(round_id, bets) do
    Enum.each(bets, fn {_key, bet} ->
      if bet.status == "active" do
        case Talon.Repo.get_by(Talon.Bet, user_id: bet.user_id, session_id: bet.session_id, round_id: round_id) do
          nil ->
            Talon.Repo.insert!(%Talon.Bet{
              id: Ecto.UUID.generate(), user_id: bet.user_id, amount: bet.amount,
              auto_cashout: bet.auto_cashout, session_id: bet.session_id,
              round_id: round_id, status: "lost"
            })
          existing ->
            existing |> Ecto.Changeset.change(status: "lost") |> Talon.Repo.update!()
        end
      end
    end)
  end

  defp serialize_state(state) do
    %{
      round_id: state.round_id,
      hash: state.hash,
      status: state.status,
      multiplier: if(is_struct(state.multiplier, Decimal), do: Decimal.to_string(state.multiplier), else: "1.00"),
      crash_point: if(state.crash_point, do: Decimal.to_string(state.crash_point), else: nil),
      bets: Enum.map(state.bets, fn {_k, v} -> Map.take(v, [:user_id, :amount, :status, :payout, :cashout_multiplier]) end),
      player_count: map_size(state.bets)
    }
  end

  defp broadcast_state(state) do
    Phoenix.PubSub.broadcast(Talon.PubSub, "crash_game:global", {:round_update, serialize_state(state)})
  end
end
