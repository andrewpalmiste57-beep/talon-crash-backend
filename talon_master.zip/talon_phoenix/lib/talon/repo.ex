defmodule Talon.Repo do
  use Ecto.Repo,
    otp_app: :talon,
    adapter: Ecto.Adapters.Postgres
end
