defmodule TalonWeb.Router do
  use TalonWeb, :router

  pipeline :api do
    plug :accepts, ["json"]
    plug TalonWeb.SecurityPlug
  end

  scope "/api", TalonWeb do
    pipe_through :api
    get "/health", HealthController, :index
    get "/round/current", RoundController, :current
    post "/bet", BetController, :place
    post "/cashout", CashoutController, :execute
  end
end
