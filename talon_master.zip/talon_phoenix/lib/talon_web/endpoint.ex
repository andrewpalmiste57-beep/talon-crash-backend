defmodule TalonWeb.Endpoint do
  use Phoenix.Endpoint, otp_app: :talon

  @session_options [
    store: :cookie,
    key: "_talon_key",
    signing_salt: "talon_salt",
    same_site: "Lax"
  ]

  socket "/socket", TalonWeb.CrashGameSocket,
    websocket: [
      check_origin: false,
      connect_info: [:peer_data, :x_headers]
    ],
    longpoll: false

  plug Plug.Static,
    at: "/",
    from: :talon,
    gzip: false,
    only: TalonWeb.static_paths()

  if code_reloading? do
    plug Phoenix.CodeReloader
  end

  plug Plug.RequestId
  plug Plug.Telemetry, event_prefix: [:phoenix, :endpoint]

  plug Plug.Parsers,
    parsers: [:urlencoded, :multipart, :json],
    pass: ["*/*"],
    json_decoder: Phoenix.json_library()

  plug Plug.MethodOverride
  plug Plug.Head
  plug Plug.Session, @session_options
  plug TalonWeb.SecurityPlug
  plug TalonWeb.Router
end
