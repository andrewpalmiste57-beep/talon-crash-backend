defmodule TalonWeb.SecurityPlug do
  @moduledoc "Security middleware: CORS, headers, and request validation."
  import Plug.Conn
  require Logger

  def init(options), do: options

  def call(conn, _opts) do
    conn
    |> put_resp_header("x-content-type-options", "nosniff")
    |> put_resp_header("x-frame-options", "DENY")
    |> put_resp_header("x-xss-protection", "1; mode=block")
    |> put_resp_header("referrer-policy", "strict-origin-when-cross-origin")
    |> put_resp_header("strict-transport-security", "max-age=31536000; includeSubDomains")
    |> validate_request_size()
    |> check_user_agent()
  end

  defp validate_request_size(conn) do
    case Plug.Conn.get_req_header(conn, "content-length") do
      [len] ->
        if String.to_integer(len) > 10_000 do
          conn |> send_resp(413, "Payload too large") |> halt()
        else
          conn
        end
      _ -> conn
    end
  end

  defp check_user_agent(conn) do
    case Plug.Conn.get_req_header(conn, "user-agent") do
      [] -> conn
      _ -> conn
    end
  end
end
