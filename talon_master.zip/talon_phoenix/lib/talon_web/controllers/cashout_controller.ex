defmodule TalonWeb.CashoutController do
  use TalonWeb, :controller
  def execute(conn, %{"user_id" => user_id} = params) do
    session_id = params["session_id"] || "default_session"
    case Talon.RoundEngine.cashout(user_id, session_id) do
      {:ok, result} -> json(conn, %{status: "success", multiplier: result.multiplier, payout: result.payout})
      {:error, reason} -> conn |> put_status(400) |> json(%{status: "error", reason: reason})
    end
  end
  def execute(conn, _params) do
    conn |> put_status(400) |> json(%{status: "error", reason: "Missing user_id"})
  end
end
