defmodule TalonWeb.HealthController do
  use TalonWeb, :controller
  def index(conn, _params) do
    json(conn, %{status: "ok", version: "3.2.0", timestamp: DateTime.utc_now()})
  end
end
