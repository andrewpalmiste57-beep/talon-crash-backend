defmodule TalonWeb.BetController do
  use TalonWeb, :controller
  def place(conn, %{"amount" => amount, "user_id" => user_id} = params) do
    session_id = params["session_id"] || Ecto.UUID.generate()
    auto_cashout = params["auto_cashout"]
    case Talon.RoundEngine.place_bet(user_id, amount, auto_cashout, session_id) do
      {:ok, msg} -> json(conn, %{status: "success", message: msg})
      {:error, reason} -> conn |> put_status(400) |> json(%{status: "error", reason: reason})
    end
  end
  def place(conn, _params) do
    conn |> put_status(400) |> json(%{status: "error", reason: "Missing required fields"})
  end
end
