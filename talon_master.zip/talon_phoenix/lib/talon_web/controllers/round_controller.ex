defmodule TalonWeb.RoundController do
  use TalonWeb, :controller
  def current(conn, _params) do
    state = Talon.RoundEngine.current_state()
    json(conn, state)
  end
end
