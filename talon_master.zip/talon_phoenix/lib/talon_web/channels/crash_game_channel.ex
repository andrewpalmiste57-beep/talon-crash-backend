defmodule TalonWeb.CrashGameChannel do
  @moduledoc "Real-time crash game channel with security hardening."
  use TalonWeb, :channel
  require Logger

  @impl true
  def join("crash_game:" <> _room_id, _payload, socket) do
    case Talon.RateLimiter.check_rate(socket.assigns.user_id, :join) do
      :ok ->
        send(self(), :after_join)
        {:ok, assign(socket, :joined_at, System.monotonic_time(:second))}
      {:error, reason} ->
        {:error, %{reason: reason}}
    end
  end

  @impl true
  def handle_info(:after_join, socket) do
    state = Talon.RoundEngine.current_state()
    push(socket, "round_state", state)
    Phoenix.PubSub.subscribe(Talon.PubSub, "crash_game:global")
    {:noreply, socket}
  end

  @impl true
  def handle_in("place_bet", %{"amount" => amount} = payload, socket) do
    auto_cashout = payload["auto_cashout"]
    user_id = socket.assigns.user_id
    session_id = socket.assigns.session_id
    case Talon.RoundEngine.place_bet(user_id, amount, auto_cashout, session_id) do
      {:ok, msg} ->
        Talon.BetLedger.record_bet(user_id, nil, amount, %{channel: true, auto_cashout: auto_cashout})
        {:reply, {:ok, %{status: "placed", message: msg}}, socket}
      {:error, reason} ->
        {:reply, {:error, %{reason: reason}}, socket}
    end
  end

  @impl true
  def handle_in("cashout", _payload, socket) do
    user_id = socket.assigns.user_id
    session_id = socket.assigns.session_id
    case Talon.RoundEngine.cashout(user_id, session_id) do
      {:ok, result} ->
        {:reply, {:ok, %{status: "cashed_out", multiplier: result.multiplier, payout: result.payout}}, socket}
      {:error, reason} ->
        {:reply, {:error, %{reason: reason}}, socket}
    end
  end

  @impl true
  def handle_in("ping", _payload, socket) do
    {:reply, {:ok, %{pong: true, timestamp: System.system_time(:millisecond)}}, socket}
  end

  @impl true
  def handle_info({:round_update, state}, socket) do
    push(socket, "round_update", state)
    {:noreply, socket}
  end

  @impl true
  def handle_info({:auto_cashout, ac}, socket) do
    if ac.user_id == socket.assigns.user_id and ac.session_id == socket.assigns.session_id do
      push(socket, "auto_cashout", %{multiplier: ac.multiplier, payout: ac.payout})
    end
    {:noreply, socket}
  end
end
