defmodule TalonWeb.CrashGameSocket do
  @moduledoc "WebSocket handler for crash game channels."
  use Phoenix.Socket

  channel "crash_game:*", TalonWeb.CrashGameChannel

  @impl true
  def connect(params, socket, _connect_info) do
    session_id = params["session_id"] || Ecto.UUID.generate()
    user_id = params["user_id"] || "anon_#{:crypto.strong_rand_bytes(4) |> Base.encode16(case: :lower)}"
    socket = socket |> assign(:session_id, session_id) |> assign(:user_id, user_id) |> assign(:connected_at, System.monotonic_time(:second))
    {:ok, socket}
  end

  @impl true
  def id(socket), do: "crash_game_socket:#{socket.assigns.user_id}:#{socket.assigns.session_id}"
end
