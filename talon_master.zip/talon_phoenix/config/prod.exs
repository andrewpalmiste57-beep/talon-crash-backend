import Config

config :talon, Talon.Repo,
  url: System.get_env("DATABASE_URL") || "ecto://talon:talon_secure_2026@localhost/talon_production",
  pool_size: String.to_integer(System.get_env("POOL_SIZE") || "10"),
  ssl: false,
  prepare: :named

config :talon, TalonWeb.Endpoint,
  url: [host: System.get_env("PHX_HOST") || "localhost", port: 443, scheme: "https"],
  http: [ip: {0, 0, 0, 0}, port: String.to_integer(System.get_env("PORT") || "4000")],
  secret_key_base: System.get_env("SECRET_KEY_BASE") || "change_me_in_production_64_chars_long_minimum_talon_2026",
  check_origin: ["https://warp-vortex-backend2.onrender.com", "http://localhost:8080"],
  server: true

config :logger, level: :info
