import Config

config :talon, Talon.Repo,
  username: "talon",
  password: "talon_secure_2026",
  hostname: "localhost",
  database: "talon_production",
  stacktrace: true,
  show_sensitive_data_on_connection_error: true,
  pool_size: 10

config :talon, TalonWeb.Endpoint,
  http: [ip: {127, 0, 0, 1}, port: 4000],
  check_origin: false,
  code_reloader: false,
  debug_errors: true,
  secret_key_base: "dev_secret_key_base_talon_2026_change_in_production_64_chars_long_minimum",
  watchers: []

config :logger, :console, format: "[$level] $message\n"

config :phoenix, :stacktrace_depth, 20
config :phoenix, :plug_init_mode, :runtime
