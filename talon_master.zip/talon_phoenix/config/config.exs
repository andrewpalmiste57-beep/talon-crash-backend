import Config

config :talon,
  ecto_repos: [Talon.Repo],
  generators: [timestamp_type: :utc_datetime_usec]

config :talon, TalonWeb.Endpoint,
  url: [host: "localhost"],
  adapter: Phoenix.Endpoint.Cowboy2Adapter,
  render_errors: [
    formats: [json: TalonWeb.ErrorJSON],
    layout: false
  ],
  pubsub_server: Talon.PubSub,
  live_view: [signing_salt: "talon_salt_2026"]

config :logger, :console,
  format: "$time $metadata[$level] $message\n",
  metadata: [:request_id]

config :phoenix, :json_library, Jason

import_config "#{config_env()}.exs"
