# TALON Security Hardening Guide

## Threat Model & Mitigations

| Attack Vector | Mitigation | File |
|---|---|---|
| Ghost Cashout (double-cashout same bet) | `CashoutGuardian` atomically tracks `{user_id,session_id,round_id}` | `lib/talon/cashout_guardian.ex` |
| Multiplier Leak (predict crash before round) | Hash commitment: `hash = SHA256(seed)` published before round starts | `lib/talon/provably_fair.ex` |
| Replay Attack (replay old cashout msg) | Unique nonce per bet + DB unique index on `user_id+session_id+round_id` | `priv/repo/migrations/002_create_bets.exs` |
| Race Double-Spend | `atomic_cashout()` PostgreSQL function with `FOR UPDATE` row lock | `priv/repo/migrations/004_add_atomic_cashout_function.exs` |
| Rate Limiting Abuse | `RateLimiter` GenServer: 5 bets/10s, 10 cashouts/5s, 100 ops/s global | `lib/talon/rate_limiter.ex` |
| Data Isolation | PostgreSQL RLS policies isolate rows per `user_id` | `priv/repo/migrations/006_enable_rls.exs` |
| SQL Injection | Ecto parameterized queries only — no raw SQL in controllers | All controllers |
| XSS / Clickjacking | Security headers: `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff` | `lib/talon_web/plugs/security_plug.ex` |
| WebSocket Hijacking | `check_origin: false` (Termux) + session binding per socket ID | `lib/talon_web/channels/crash_game_socket.ex` |
| Brute Force Joins | Rate limit on `join` action per user_id | `lib/talon_web/channels/crash_game_channel.ex` |
| Oversized Payloads | Request body capped at 10KB | `lib/talon_web/plugs/security_plug.ex` |

## Network Hardening (Termux)

```bash
# Block all inbound except localhost:4000
iptables -A INPUT -p tcp --dport 4000 -s 127.0.0.1 -j ACCEPT
iptables -A INPUT -p tcp --dport 4000 -j DROP
iptables -A INPUT -p tcp --dport 5432 -j DROP
```

## Environment Security

Never commit `.env` files. Required secrets:
- `SECRET_KEY_BASE` — 64+ chars, `mix phx.gen.secret`
- `DATABASE_URL` — use SSL in production
- `PHX_HOST` — your domain

## Audit Trail

All bets, cashouts, and round seeds are persisted with `utc_datetime_usec` timestamps.
RLS ensures users can only read their own bet history.
